<script nonce="GGYJ/2qfSrRZ6m5Sk3Ut8M18iQ9KjQLFmLyLkkoCII0=">self.document.location.replace('/duoback')</script><!-- ================= #HTML_HEADER :: START. 파일위치 : _modules/common/html_header.html ================= -->
<!-- ++++++++++++++++++++++++++++++++++++++++++++++++++++
@@ #HTML_HEADER @@
- 파일위치 : [스킨폴더]/_modules/common/html_header.html
++++++++++++++++++++++++++++++++++++++++++++++++++++ -->
<!doctype html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="ko" xml:lang="ko"  xmlns:fb="http://ogp.me/ns/fb#"  xmlns:og="http://ogp.me/ns#">
<head prefix="og: http://ogp.me/ns# fb: http://ogp.me/ns/fb# website: http://ogp.me/ns/fb/website#">
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta charset="utf-8">

<script nonce="GGYJ/2qfSrRZ6m5Sk3Ut8M18iQ9KjQLFmLyLkkoCII0=">window.Firstmall = window.Firstmall || {};
window.Firstmall.Config = {"Environment":{"MobileMode":true,"SetMode":null,"Language":"KR","Currency":{"Basic":{"Id":"KRW","Symbol":"원","Position":"after"},"Skin":{"Id":"KRW","Symbol":"원","Position":"after"}},"serviceLimit":{"H_FR":false,"H_AD":true},"OperationType":"light","Protocol":"https","CacheBreaker":"40ab8bcfa0f789f4f2c42141a2313994238a377d"},"Security":{"PreventDrag":false,"PreventContextMenu":false},"Search":{"AutoComplete":true,"Suggest":false}};
(function(){ var aliases = {"gl_operation_type":window.Firstmall.Config.Environment.OperationType,"gl_mobile_mode":window.Firstmall.Config.Environment.MobileMode,"gl_set_mode":window.Firstmall.Config.Environment.SetMode,"gl_language":window.Firstmall.Config.Environment.Language,"gl_basic_currency":window.Firstmall.Config.Environment.Currency.Basic.Id,"gl_skin_currency":window.Firstmall.Config.Environment.Currency.Skin.Id,"gl_basic_currency_symbol":window.Firstmall.Config.Environment.Currency.Basic.Symbol,"gl_basic_currency_symbol_position":window.Firstmall.Config.Environment.Currency.Basic.Position,"gl_protocol":window.Firstmall.Config.Environment.Protocol+"://"}; for(var attr in aliases) { window[attr] = aliases[attr]; }})();</script>
<!-- <meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests" />  -->
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0">
<meta http-equiv="Content-Script-Type" content="text/javascript" />
<meta http-equiv="Content-Style-Type" content="text/css" />
<meta name="facebook-domain-verification" content="nug0dv3lefa93m66ryczcrmqy7w1np" />
	<meta name="naver-site-verification" content="56010b951fd612e714ac28450e47dfb84313e113" />
			<title>듀오백</title>
	<meta name="Robots" content="index,follow" />
<meta name="title" content="듀오백" />
<meta name="author" content="듀오백" />
<meta name="description" content="앉는 모든 것,  I'm your BACK  DUOBACK. 의자에 앉지 마세요 듀오백에 앉으세요." />
<meta name="keywords" content="듀오백" />
	
	<!-- SEO 설정이 있을경우 -->

	<meta property="og:url" content="https://www.duoback.co.kr/board/chrome-extension://hhojmcideegachlhfgfdhailpfhgknjm/web_accessible_resources/index.js" />
<meta property="og:site_name" content="듀오백" />
<meta property="og:title" content="듀오백" />

	<meta property="og:description" content="앉는 것에 대한 모든 것 All about seating I m your BACK DUOBACK" />

	<meta property="fb:app_id" content="496090777587666" />
		<meta property="og:type" content="website" />


<!-- CSS -->
<link rel="stylesheet" type="text/css" href="/data/font/font.css" />

<!-- 구글 웹폰트 -->
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@100;200;300;400;500;600;700;800;900&family=Noto+Sans+KR:wght@100;300;400;500;700;900&display=swap" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/gh/moonspam/NanumBarunGothic@latest/nanumbarungothicsubset.css">
<!--<link href="http://www.openhiun.com/hangul/nanumbarungothic.css" rel="stylesheet" type="text/css">-->


<link rel="stylesheet" type="text/css" href="/data/skin/responsive_ver1_default_gl_1/css/jqueryui/black-tie/jquery-ui-1.8.16.custom.css" />
<link rel="stylesheet" type="text/css" href="/app/javascript/plugin/slick/slick.css"><!-- 반응형 슬라이드 -->
<link rel="stylesheet" type="text/css" href="/data/design/goods_info_style.css"><!-- 상품디스플레이 CSS -->
<link rel="stylesheet" type="text/css" href="/data/design/goods_info_user.css"><!-- ++++++++++++ 상품디스플레이 사용자/제작자 CSS ++++++++++++ -->
<link rel="stylesheet" type="text/css" href="/data/skin/responsive_ver1_default_gl_1/css/lib.css" />
<!-- <link rel="stylesheet" type="text/css" href="/data/skin/responsive_ver1_default_gl_1/css/common.css" /> -->
<link rel="stylesheet" type="text/css" href="/data/skin/responsive_ver1_default_gl_1/css/common.css?v1.0" />
<link rel="stylesheet" type="text/css" href="/data/skin/responsive_ver1_default_gl_1/css/board.css" />
<link rel="stylesheet" type="text/css" href="/data/skin/responsive_ver1_default_gl_1/css/buttons.css" />
<link rel="stylesheet" type="text/css" href="/data/skin/responsive_ver1_default_gl_1/css/mobile_pagination.css" />
<link rel="stylesheet" type="text/css" href="/link/css?k=quickdesign&v=20220206215044" /><!-- Quick Design CSS -->
<link rel="stylesheet" type="text/css" href="/data/skin/responsive_ver1_default_gl_1/css/user.css" /><!-- ++++++++++++ 스킨 사용자/제작자 CSS ++++++++++++ -->
<!-- <link rel="stylesheet" type="text/css" href="/data/skin/responsive_ver1_default_gl_1/css/ab_custom.css" /> -->
<link rel="stylesheet" type="text/css" href="/data/skin/responsive_ver1_default_gl_1/css/ab_custom.css?v1.0" />
<link rel="stylesheet" type="text/css" href="/data/skin/responsive_ver1_default_gl_1/css/dev.css?" /><!-- ++++++++++++ 개발용 CSS ++++++++++++ -->
<!-- 파비콘 -->
<link rel="shortcut icon" href="https://www.duoback.co.kr//data/icon/favicon/faviconFile.ico" />
<link rel="stylesheet" href="/app/javascript/plugin/touchSlider/swiper.css" />
<!-- /CSS -->
<link rel="stylesheet" type="text/css" href="/app/javascript/plugin/jquery_swipe/jquery_swipe.css" />
<!-- 자바스크립트 -->
<script src="/app/javascript/jquery/jquery.min.js"></script>
<script src="/app/javascript/jquery/jquery-ui.min.js"></script>
<script src="/app/javascript/plugin/jquery.poshytip.min.js"></script>
<script src="/app/javascript/plugin/jquery.activity-indicator-1.0.0.min.js"></script>
<script src="/app/javascript/plugin/jquery.cookie.js"></script>
<script src="/app/javascript/plugin/jquery.slides.min.js"></script>
<script src="/app/javascript/plugin/jquery.placeholder.js"></script>
<script src="/app/javascript/plugin/validate/jquery.validate.js"></script>
<script src="/app/javascript/plugin/ezmark/js/jquery.ezmark.min.js"></script>
<script src="/app/javascript/plugin/custom-select-box.js"></script>
<script src="/app/javascript/plugin/custom-mobile-pagination.js"></script>
<script src="/app/javascript/plugin/slick/slick.min.js"></script>
<script src="/app/javascript/plugin/jquery_swipe/jquery.event.swipe.js"></script>
<!--<script src="/app/javascript/plugin/touchSlider/swiper.js"></script-->
<script src="/data/skin/responsive_ver1_default_gl_1/common/swiper.min.js"></script>

	<script src="//cdn.jsdelivr.net/npm/mobile-detect@1.4.5/mobile-detect.min.js"></script>

	<!-- crema_review -->
	<script> var md = new MobileDetect(window.navigator.userAgent); if (md.mobile()) { (function(i,s,o,g,r,a,m){if(s.getElementById(g));a=s.createElement(o),m=s.getElementsByTagName(o)[0];a.id=g;a.async=1;a.src=r;m.parentNode.insertBefore(a,m)})(window,document,'script','crema-jssdk','//widgets.cre.ma/duoback.co.kr/mobile/init.js'); } else { (function(i,s,o,g,r,a,m){if(s.getElementById(g));a=s.createElement(o),m=s.getElementsByTagName(o)[0];a.id=g;a.async=1;a.src=r;m.parentNode.insertBefore(a,m)})(window,document,'script','crema-jssdk','//widgets.cre.ma/duoback.co.kr/init.js'); } </script>
		<script>
		window.cremaAsyncInit = function () {
			crema.init(null, null);
		}
	</script>
		


<script>
var REQURL = '/board/chrome-extension://hhojmcideegachlhfgfdhailpfhgknjm/web_accessible_resources/index.js';
var WINDOWWIDTH = window.innerWidth;
</script>


<style type="text/css">

/* 레이아웃설정 폰트 적용 */
#layout_body body,
#layout_body table,
#layout_body div,
#layout_body input,
#layout_body textarea,
#layout_body select,
#layout_body span
{
}

/* 레이아웃설정 스크롤바색상 적용 */
</style>


<!-- /자바스크립트 -->
	
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'/data/skin/responsive_ver1_default_gl_1/_modules/common/gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-MW6842V');</script>
<!-- End Google Tag Manager -->
	
<script>
			(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
			(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
			m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
			})(window,document,'script','//www.google-analytics.com/analytics.js','ga');
			ga('create', 'UA-47864109-1', 'auto');
			ga_require_ec = false;
			ga('send', 'pageview');
			</script><script src="/app/javascript/js/dev-tools.js?v=40ab8bcfa0f789f4f2c4"></script><script src="/app/javascript/js/goods-display_mobile.js?v=40ab8bcfa0f789f4f2c4"></script><script src="/app/javascript/js/design.js?v=40ab8bcfa0f789f4f2c4"></script><script src="/app/javascript/js/common.js?v=40ab8bcfa0f789f4f2c4"></script><script src="/app/javascript/js/common-mobile.js?v=40ab8bcfa0f789f4f2c4"></script><script src="/app/javascript/js/front-layout.js?v=40ab8bcfa0f789f4f2c4"></script><script src="/app/javascript/js/base64.js?v=40ab8bcfa0f789f4f2c4"></script><script src="/app/javascript/js/skin-responsive.js?v=40ab8bcfa0f789f4f2c4"></script><script src="/data/js/language/L10n_KR.js?v=40ab8bcfa0f789f4f2c4"></script><script src="/data/skin/responsive_ver1_default_gl_1/common/jquery.event.drag-1.5.min.js?v=40ab8bcfa0f789f4f2c4"></script><script src="/data/skin/responsive_ver1_default_gl_1/common/jquery.touchSlider.js?v=40ab8bcfa0f789f4f2c4"></script><script src="/data/skin/responsive_ver1_default_gl_1/common/responsive.js?v=40ab8bcfa0f789f4f2c4"></script><script src="/data/skin/responsive_ver1_default_gl_1/common/script.js?v=40ab8bcfa0f789f4f2c4"></script><script src="/data/skin/responsive_ver1_default_gl_1/common/search_ver2.js?v=40ab8bcfa0f789f4f2c4"></script><script src="/data/skin/responsive_ver1_default_gl_1/common/user.js?v=40ab8bcfa0f789f4f2c4"></script><script src="/app/javascript/plugin/jquery.bxslider.js?v=40ab8bcfa0f789f4f2c4"></script>
</head>
	
<!-- Facebook Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window,document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
 fbq('init', '428670010887545'); 
fbq('track', 'PageView');
</script>
<noscript>
 <img height="1" width="1" 
src="https://www.facebook.com/tr?id=428670010887545&ev=PageView
&noscript=1"/>
</noscript>
<!-- End Facebook Pixel Code -->

<body>


<!-- ================= #HTML_HEADER :: END. 파일위치 : _modules/common/html_header.html ================= -->

<!--[ 디자인모드 호출 스크립트]-->

<!--[ 모바일쇼핑몰 디자인모드시 화면 구성]-->

<style>
#layout_body {
background-color:#ffffff;}
#layer_pay {position:absolute;top:0px;width:100%;height:100%;background-color:#ffffff;text-align:center;z-index:999999;}
#payprocessing {text-align:center;position:absolute;width:100%;top:150px;z-index:99999999px;}
</style>

<div id="wrap">
	<!-- ================= 어사이드 :: START. 파일위치 : _modules/common/layout_side.html (비동기 로드) ================= -->
	<div id="layout_side" class="layout_side"></div>
	<!-- ================= 어사이드 :: END. 파일위치 : _modules/common/layout_side.html (비동기 로드) ================= -->
	<a href="javascript:;" id="side_close" class="side_close">어사이드 닫기</a>

	<div id="layout_wrap" class="layout_wrap">

		<div id="layout_body" class="layout_body">
		<!-- ================= 파트 페이지들 :: START. ================= -->
<!DOCTYPE html>
<html lang="ko">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0">
<title>Error 404 - Page Not Found</title>
<link rel="stylesheet" type="text/css" href="/data/skin/responsive_ver1_default_gl_1/css/common.css" />
<style type="text/css">
.intro_content {text-align:center; }
.intro_title {font-size:32px; line-height:1.3; font-weight:400;color:#000;padding-top:40px;}
.intro_title2 {font-size:21px; line-height:1.3; font-weight:100;color:#999;padding-top:20px;}
.intro_title_small {font-size:17px; font-weight:300; padding:10px 0px 0;}
.intro_btns { padding-top:30px; }
</style>
<script>
			(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
			(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
			m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
			})(window,document,'script','//www.google-analytics.com/analytics.js','ga');
			ga('create', 'UA-47864109-1', 'auto');
			ga_require_ec = false;
			ga('send', 'pageview');
			</script><script src="/app/javascript/plugin/jquery.bxslider.js?v=40ab8bcfa0f789f4f2c4"></script>
</head>
<body>

<div class="full_layout">
	<ul class="single_contents">
		<li>
			<div class="intro_content">
				<p><img src="/data/skin/responsive_ver1_default_gl_1/images/common/pc_img_404.gif" alt="Error 404" /></p>
				<p class="intro_title">Error 404 - Page Not Found</p>
				<p class="intro_title2 Fw100">
					요청하신 페이지를 찾을 수 없습니다.<br />
					URL을 다시 확인하시기 바랍니다.<br />
				</p>
				<p class="intro_btns">
					<a class="btn_resp size_c color2 Fw100" href="/">쇼핑몰 바로가기</a>
				</p>
				<p class="intro_title_small" style="padding-top:30px;">
					(주) 듀오백 &nbsp;|&nbsp; <a href="tel:1588-2501">1588-2501</a>
				</p>
			</div>
		</li>
	</ul>
</div>

<script type="text/javascript">
var isMobile = {
    Android: function() {
        return navigator.userAgent.match(/Android/i);
    },
    BlackBerry: function() {
        return navigator.userAgent.match(/BlackBerry/i);
    },
    iOS: function() {
        return navigator.userAgent.match(/iPhone|iPad|iPod/i);
    },
    Opera: function() {
        return navigator.userAgent.match(/Opera Mini/i);
    },
    Windows: function() {
        return navigator.userAgent.match(/IEMobile/i);
    },
    any: function() {
        return (isMobile.Android() || isMobile.BlackBerry() || isMobile.iOS() || isMobile.Opera() || isMobile.Windows());
    }
};
</script>

</body>
</html>
		<!-- ================= 파트 페이지들 :: END. ================= -->
		</div>


		<iframe name="actionFrame" id="actionFrame" src="/main/blank" frameborder="0" width="100%" height="0"></iframe>
		<div id="openDialogLayer" style="display: none">
			<div align="center" id="openDialogLayerMsg"></div>
		</div>
		<div id="ajaxLoadingLayer" style="display: none"></div>
	</div>	
</div>
<div id="mobileZipcodeLayer" style="display: none"></div>
<!-- 결제창을 레이어 형태로 구현-->
<div id="layer_pay" class="hide"></div>
<div id="payprocessing" class="pay_layer hide">
	<div style="margin:auto;"><img src="/data/skin/responsive_ver1_default_gl_1/images/design/img_paying.gif" /></div>
	<div style="margin:auto;padding-top:20px;"><img src="/data/skin/responsive_ver1_default_gl_1/images/design/progress_bar.gif" /></div>
</div>
<div id="layout_side_background" class="layout_side_background"></div>

<!-- ================= #HTML_FOOTER :: START. 파일위치 : _modules/common/html_footer.html ================= -->
<!-- ++++++++++++++++++++++++++++++++++++++++++++++++++++
@@ #HTML_FOOTER @@
- 파일위치 : [스킨폴더]/_modules/common/html_footer.html
++++++++++++++++++++++++++++++++++++++++++++++++++++ -->
<div id="popupChangePassword" class="resp_layer_pop hide">
	<h4 class="title">비밀번호 변경</h4>
	<form id='passUpdateForm' method='post' action='/login_process/popup_change_pass' target='actionFrame'>
	<input type='hidden' name='password_mode' value='update'>
		<div class="y_scroll_auto2">
			<div class="layer_pop_contents v5">
				<h5 class="stitle">회원님의 소중한 개인정보 보호를 위해 비밀번호를 주기적으로 변경하시는 것이 좋습니다.</h5>
				<p class="desc Pb8">※ 비밀번호는 6~20자, 영문 대소문자 또는 숫자 특수문자 중 2가지 이상 조합.</p>
				<div class="resp_table_row input_form th_size3">
					<ul class="tr">
						<li class="th Pl5 Pr5">현재 비밀번호</li>
						<li class="td">
							<input type='password' name='old_password' value='' class='passwordField eng_only Wmax' />
						</li>
					</ul>
					<ul class="tr">
						<li class="th Pl5 Pr5">신규 비밀번호</li>
						<li class="td">
							<input type='password' name='new_password' value='' class='passwordField eng_only Wmax' />
						</li>
					</ul>
					<ul class="tr">
						<li class="th Pl5 Pr5">신규 비밀번호 <span class="Dib">확인</span></li>
						<li class="td">
							<input type='password' name='re_new_password' value='' class='passwordField eng_only Wmax' />
						</li>
					</ul>
				</div>
				<div class="C Pt20 Fs15">
					<label><input type='checkbox' name='update_rate' value='Y' onclick='update_rate_checked();'> 개월 이후에 비밀번호를 변경하겠습니다.</label>
				</div>
			</div>
		</div>
		<div class="layer_bottom_btn_area2 v2">
			<ul class="basic_btn_area2">
				<li><button type="submit" class="btn_resp size_c color2">변경 완료</button></li>
				<li><button type="button" class="btn_resp size_c color5" onclick="hideCenterLayer()">취소</button></li>
			</ul>
		</div>
		<a href="javascript:void(0)" class="btn_pop_close" onclick="hideCenterLayer()"></a>
	</form>
</div>
<script type="text/javascript" src="https://wcs.naver.net/wcslog.js"></script>
<script type="text/javascript">
	// STEP 2. na_account_id(네이버공통키) 세팅
	if(!wcs_add) var wcs_add = {};
	wcs_add["wa"] = "s_379a6b8575dd"; // wcs_add["wa"]="na_account_id" , 확인된/전달받은 na_account_id(네이버공통키) 세팅
	//STEP 3. Referrer, 현재 페이지 URL, 사용자 환경 등의 정보를 변수에 세팅 및 전환로그 수집을 위한 Cookie등의 세팅
	if (!_nasa) var _nasa={};
	wcs.inflow("duoback.co.kr"); // PC사이트와 모바일사이트의 웹로그 합하여 분석하는 경우 사이트 최상위 도메인 입력. PC와 모바일
	//사이트를 각각 별도로 분석하고 싶은 경우 값을 비워둠.
	if(window.location.pathname=='/member/register_ok') {
		_nasa["cnv"] = wcs.cnv("2","1");
	}

	if(window.location.pathname=='/order/cart') {
		_nasa["cnv"] = wcs.cnv("3",find_cart_price);
	}

	if(window.location.pathname=='/order/complete') {
		_nasa["cnv"] = wcs.cnv("1",settleprice);
	}

	// STEP 4. 변수에 세팅된 각종 정보 + 전환정보를 (네이버의) 웹로그수집서버에 전송. 전송하는 method이므로 항상 STEP 1, 2, 3 보다
	//나중에 있어야 함. (변수 세팅 등이 되지 않은 상황에서 먼저 전송하면 웹로그 수집에 오류가 발생함.)
	wcs_do(_nasa);
</script>
</body>

<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-MW6842V"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

</html>
<!-- ================= #HTML_FOOTER :: END. 파일위치 : _modules/common/html_footer.html ================= -->